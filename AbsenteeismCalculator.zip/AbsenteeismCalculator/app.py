import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

# Set page configuration
st.set_page_config(
    page_title="Absenteeism Cost Calculator",
    page_icon="💼",
    layout="wide"
)

# Custom CSS to match Health for Work branding
st.markdown("""
<style>
    /* Import Open Sans font */
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap');
    
    /* Main styling */
    .main > div {
        font-family: 'Open Sans', sans-serif;
    }
    
    /* Header styling */
    h1 {
        color: #0066CC;
        font-family: 'Open Sans', sans-serif;
        font-weight: 700;
        border-bottom: 3px solid #0066CC;
        padding-bottom: 10px;
    }
    
    h2, h3 {
        color: #0066CC;
        font-family: 'Open Sans', sans-serif;
        font-weight: 600;
    }
    
    /* Metric styling */
    [data-testid="metric-container"] {
        background-color: #F8F9FA;
        border: 1px solid #E9ECEF;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #0066CC;
    }
    
    /* Info box styling */
    .stInfo {
        background-color: #E3F2FD;
        border-left: 4px solid #0066CC;
    }
    
    /* Button styling */
    .stButton > button {
        background-color: #0066CC;
        color: white;
        border: none;
        border-radius: 5px;
        font-family: 'Open Sans', sans-serif;
        font-weight: 600;
    }
    
    .stButton > button:hover {
        background-color: #0052A3;
    }
    
    /* Expander styling */
    .streamlit-expanderHeader {
        background-color: #F8F9FA;
        border: 1px solid #0066CC;
        border-radius: 5px;
        font-family: 'Open Sans', sans-serif;
        font-weight: 600;
        color: #0066CC;
    }
    
    /* Input styling */
    .stSelectbox > div > div {
        border: 1px solid #0066CC;
        border-radius: 5px;
    }
    
    .stNumberInput > div > div > input {
        border: 1px solid #0066CC;
        border-radius: 5px;
    }
    
    .stSlider > div > div > div {
        color: #0066CC;
    }
</style>
""", unsafe_allow_html=True)

# Header with logo and title
col1, col2 = st.columns([1, 3])

with col1:
    st.image("logo.png", width=300)

with col2:
    st.title("Business Absenteeism Cost Calculator")
    st.markdown("""
    This calculator helps you understand the financial impact of employee absenteeism on your business.
    Based on industry-specific data from Australia, you can see how much absenteeism is costing you daily, monthly, quarterly, yearly, or over a decade.
    """)

# Industry data
industry_data = {
    "Mining": 180000,
    "Hospitality": 60000,
    "Tourism": 75000,
    "Retail": 75000,
    "Corporate": 100000,
    "Technical": 85000,
    "Transport": 90000,
    "Logistics": 100000,
    "Energy": 110000,
    "University and Teaching": 90000,
    "Manufacturing": 65000,
    "Construction": 75000
}

# Create columns for input form
col1, col2 = st.columns(2)

# Input form
with col1:
    st.subheader("Company Details")
    
    # Industry selection
    selected_industry = st.selectbox(
        "Select your industry:",
        options=list(industry_data.keys()),
        index=0
    )
    
    # Get default salary for selected industry and allow user to modify
    default_salary = industry_data[selected_industry]
    avg_salary = st.number_input(
        f"Annual salary per employee for {selected_industry}:",
        min_value=30000,
        max_value=500000,
        value=default_salary,
        step=1000,
        format="%d"
    )
    
    # Number of employees
    employee_count = st.number_input(
        "Number of employees:",
        min_value=1,
        max_value=100000,
        value=100,
        step=1
    )
    
    # Absenteeism rate with Australian average of 4.2%
    st.write("Australian average absenteeism rate: 4.2% per year (approx. 9 days per employee)")
    absenteeism_rate = st.slider(
        "Absenteeism rate (%):",
        min_value=0.0,
        max_value=10.0,
        value=4.2,
        step=0.1,
        format="%.1f%%"
    )
    
    # Time period selection
    time_period = st.selectbox(
        "Projection period:",
        options=["Day", "Month", "Quarter", "Year", "10 Years"],
        index=3
    )

# Calculate absenteeism cost
with col2:
    # Add an empty space to balance layout
    st.write("")
    st.write("")
    
    # How this works button (calculation methodology)
    with st.expander("How This Calculator Works"):
        st.markdown("""
        ### Calculation Methodology
        
        The financial impact is calculated using the formula:
        
        **Financial Loss = Number of Employees × Average Salary × Absenteeism Rate × Time Factor**
        
        Where:
        - **Number of Employees**: Total workforce size
        - **Average Salary**: Industry-specific average annual salary
        - **Absenteeism Rate**: Percentage of work time lost to absences
        - **Time Factor**: Portion of the year based on selected time period
        
        This calculation represents direct salary costs paid during absence and does not include indirect costs such as:
        - Replacement worker costs
        - Reduced productivity
        - Administrative costs
        - Impact on team morale
        - Customer service disruptions
        
        The actual total cost may be significantly higher than calculated here.
        """)

# Set time factors
time_factors = {
    "Day": 1/260,  # Assuming ~260 working days per year
    "Month": 1/12,
    "Quarter": 1/4,
    "Year": 1,
    "10 Years": 10
}

# Calculate the financial impact
time_factor = time_factors[time_period]
financial_loss = employee_count * avg_salary * (absenteeism_rate / 100) * time_factor

# Results section
st.header("Financial Impact Results")

# Display loss metrics in a prominent way
st.metric(
    label=f"Estimated Financial Loss Due to Absenteeism ({time_period})",
    value=f"${financial_loss:,.2f}"
)

# Calculate days lost
annual_working_days = 260  # Standard working days per year
days_lost_per_employee = annual_working_days * (absenteeism_rate / 100)
total_days_lost = days_lost_per_employee * employee_count * time_factor

# Additional metrics
col1, col2 = st.columns(2)

with col1:
    st.metric(
        label="Total Working Days Lost",
        value=f"{total_days_lost:,.1f} days"
    )

with col2:
    # Daily loss regardless of selected period (for comparison)
    daily_loss = employee_count * avg_salary * (absenteeism_rate / 100) * (1/260)
    st.metric(
        label="Daily Financial Loss",
        value=f"${daily_loss:,.2f}"
    )

# Visualizations
st.subheader("Financial Impact Over Time")

# Create a figure with time periods
periods = ["Day", "Month", "Quarter", "Year", "10 Years"]
values = [employee_count * avg_salary * (absenteeism_rate / 100) * time_factors[p] for p in periods]

fig = px.bar(
    x=periods,
    y=values,
    labels={'x': 'Time Period', 'y': 'Financial Loss ($)'},
    title=f"Financial Impact of Absenteeism Over Different Time Periods",
    color=values,
    color_continuous_scale=['#E3F2FD', '#0066CC', '#003D7A'],
)

fig.update_layout(
    xaxis_title="Time Period",
    yaxis_title="Financial Loss ($)",
    yaxis_tickformat='$,.0f',
    height=500,
    font_family="Open Sans",
    title_font_color="#0066CC",
    title_font_size=20,
)

st.plotly_chart(fig, use_container_width=True)

# Conclusion and call to action
st.header("What Does This Mean For Your Business?")
st.markdown(f"""
Based on an average salary of **${avg_salary:,}** for the **{selected_industry}** industry and an absenteeism rate of **{absenteeism_rate}%**:

- Your company with **{employee_count}** employees is losing approximately **${financial_loss:,.2f}** over **{time_period.lower()}**
- This equates to **{total_days_lost:,.1f}** working days lost during this period
- On average, each employee costs your company **${avg_salary * (absenteeism_rate / 100):,.2f}** per year in absenteeism

### How to Reduce Absenteeism Costs:
- Implement wellness programs
- Improve workplace ergonomics
- Offer flexible work arrangements
- Create a positive workplace culture
- Develop clear attendance policies
- Provide manager training for addressing absenteeism

Understanding the financial impact is the first step toward implementing effective solutions.
""")

# Footer information
st.markdown("---")
st.markdown("""
<small>Data source: Australian workforce statistics. Calculations are estimates based on average industry salaries and typical absenteeism rates.</small>
""", unsafe_allow_html=True)
